﻿# Upload packaging notes

## Moved out of scripts/ (JSON is not a allowed skill script type)


## Omitted (unsupported Copilot Studio skill file types or size)
- scripts/twx-bo-tools__empty-project.twx (unsupported script type .twx)


Allowed scripts: .py, .js, .mjs, .cjs, .ts, .mts, .sh, .bash
Allowed resources: .json, .xml, .yaml, .yml, .ini, .config, .utf8, .docx, .doc, .docm, .pdf, .txt, .rtf, .md, .ppt, .pptx, .ppsm, .xlsx, .xls, .xlsm, .csv, .tsv, .html, .htm, .png, .jpg, .jpeg, .gif, .bmp, .log
.css examples were renamed to .txt. Full trees remain in GitHub behaviors/generate-baw-business-objects/.
