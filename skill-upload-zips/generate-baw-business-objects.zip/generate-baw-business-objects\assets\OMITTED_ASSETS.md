﻿# Omitted from upload zip
- scripts/twx-bo-tools__empty-project.twx

.json/.css/.svg converted to .txt under assets/. Full sources: GitHub behaviors/generate-baw-business-objects/
