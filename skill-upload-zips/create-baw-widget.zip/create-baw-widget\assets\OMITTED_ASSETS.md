﻿# Assets omitted from upload zip (path-depth / size limits)

Copilot Studio rejects skill packages with paths deeper than 3 levels.
The following files were omitted from this upload zip. Full copies remain in the GitHub repo under `behaviors/create-baw-widget/assets/`.

- templates\BaseTWX\25.0.1\files\61.959980c4-c761-4613-a7f3-478e4b846f66\9c19cf8e-1cbc-47a9-a5ab-95eae3440b78
- templates\BaseTWX\25.0.1\META-INF\MANIFEST.MF
- templates\BaseTWX\25.0.1\META-INF\metadata.xml
- templates\BaseTWX\25.0.1\META-INF\package.xml
- templates\BaseTWX\25.0.1\META-INF\properties.json
- templates\BaseTWX\25.0.1\objects\61.959980c4-c761-4613-a7f3-478e4b846f66.xml
- templates\BaseTWX\25.0.1\objects\62.7ff4028f-8539-42cd-83b3-ccb0d0373180.xml
- templates\BaseTWX\25.0.1\objects\63.16da6deb-ba5f-4f5e-bbaf-cd5ff2e3c4b1.xml

