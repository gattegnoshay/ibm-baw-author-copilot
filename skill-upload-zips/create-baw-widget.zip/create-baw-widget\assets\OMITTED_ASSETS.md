﻿# Upload packaging notes

## Moved out of scripts/ (JSON is not a allowed skill script type)
- toolkit_packager__baw_type_mappings.json -> assets/from_scripts__toolkit_packager__baw_type_mappings.json
- toolkit_packager__README.md (non-script) -> assets/


## Omitted (unsupported Copilot Studio skill file types or size)
- resource/examples__DateOutput__DateOutput.svg (unsupported type .svg)
- resource/examples__TasksList__TasksList.svg (unsupported type .svg)
- assets/templates\BaseTWX\25.0.1\files\61.959980c4-c761-4613-a7f3-478e4b846f66\9c19cf8e-1cbc-47a9-a5ab-95eae3440b78
- assets/templates\BaseTWX\25.0.1\META-INF\MANIFEST.MF
- assets/templates\BaseTWX\25.0.1\META-INF\metadata.xml
- assets/templates\BaseTWX\25.0.1\META-INF\package.xml
- assets/templates\BaseTWX\25.0.1\META-INF\properties.json
- assets/templates\BaseTWX\25.0.1\objects\61.959980c4-c761-4613-a7f3-478e4b846f66.xml
- assets/templates\BaseTWX\25.0.1\objects\62.7ff4028f-8539-42cd-83b3-ccb0d0373180.xml
- assets/templates\BaseTWX\25.0.1\objects\63.16da6deb-ba5f-4f5e-bbaf-cd5ff2e3c4b1.xml


Allowed scripts: .py, .js, .mjs, .cjs, .ts, .mts, .sh, .bash
Allowed resources: .json, .xml, .yaml, .yml, .ini, .config, .utf8, .docx, .doc, .docm, .pdf, .txt, .rtf, .md, .ppt, .pptx, .ppsm, .xlsx, .xls, .xlsm, .csv, .tsv, .html, .htm, .png, .jpg, .jpeg, .gif, .bmp, .log
.css examples were renamed to .txt. Full trees remain in GitHub behaviors/create-baw-widget/.
