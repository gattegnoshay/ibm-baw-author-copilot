# Test suite format

This is the canonical structure for all test suites that the `generate-baw-tests` skill generates.
Both Phase A (generation) and Phase B (execution) read this format. Treat it as the contract between the two phases.

---

## Top-level structure

```json
{
  "schema_version": "1.0",
  "app": {
    "name": "Human-readable process application name",
    "acronym": "ACRONYM",
    "snapshot": "SNAP_ACRONYM",
    "process_model": "Fully qualified process model ID (e.g. 'Standard Employee Requisition')"
  },
  "generated_at": "ISO-8601 timestamp",
  "test_cases": [ /* array of test case objects — see below */ ]
}
```

---

## Test case object

```json
{
  "id": "TC-001",
  "name": "Short human-readable name",
  "type": "process | coach",
  "path": "happy | alternative | error | boundary | edge",
  "description": "One or two sentences describing what this test validates.",
  "preconditions": {
    "description": "What must be true before the test starts.",
    "required_data": {}
  },
  "input": {
    "description": "Initial process start data",
    "data": {
      "field_name": "value"
    }
  },
  "steps": [ /* array of step objects — see below */ ],
  "expected_outcome": {
    "final_status": "Completed | Terminated | Failed",
    "output_variables": {
      "field_name": "expected_value"
    },
    "notes": "Optional human note about what constitutes a pass."
  },
  "coach_assertions": [ /* only for type: coach — see below */ ],
  "tags": ["optional", "labels"]
}
```

---

## Step object (for `type: process`)

Each step represents one user task interaction.

```json
{
  "step_number": 1,
  "task_name": "Exact BAW task name as it appears in Process Designer",
  "description": "What the user is doing at this step.",
  "expected_business_data": {
    "field_name": "value expected to already be on the task when claimed"
  },
  "output": {
    "field_name": "value to supply when completing the task"
  },
  "expected_next": {
    "task_or_gateway": "Name of the next expected task or gateway outcome",
    "rationale": "Why this path is taken given the output data above"
  }
}
```

Rules for steps:
- `task_name` must match the BPMN task label exactly as authored. The execution engine matches by name.
- `expected_business_data` captures assertions about data already present on the task (passed in from a previous step or set at process start). Leave it empty (`{}`) if the step needs no assertions.
- `output` is the data payload that the skill sends when it completes the task. For conditional gateways, the output values here determine which branch the process takes.
- `expected_next` captures the anticipated next step. For end events, set `task_or_gateway` to `"[End Event]"`.

---

## Coach assertion object (for `type: coach`)

Coach tests validate field behavior from the artifact definition. You run them manually. They do not run through the process execution API.

```json
{
  "field_id": "BAW coach view binding or element ID",
  "field_label": "Label as shown in the UI",
  "assertions": [
    {
      "assertion_type": "required | read_only | hidden | validation_message | default_value | min_length | max_length | regex_pattern",
      "condition": "Describe the condition under which this assertion applies (e.g. 'when approval_needed is true')",
      "expected": "The expected behavior or value",
      "test_data": "The input to use when testing this assertion"
    }
  ]
}
```

Assertion types:
- `required`: the field must be non-empty to allow form submission.
- `read_only`: the field is display-only, and the user cannot edit it.
- `hidden`: the field is not visible under the given condition.
- `validation_message`: an error message appears when the user supplies the given `test_data`.
- `default_value`: the field prepopulates with a specific value.
- `min_length`, `max_length`, `regex_pattern`: constraint validation on text inputs.

---

## Path labels

Use exactly these values for `path`:

| Value | Meaning |
|---|---|
| `happy` | The ideal, unobstructed end-to-end flow: no errors, all approvals granted, all thresholds met. |
| `alternative` | A legitimate path other than the happy path (for example, approval rejected, routed to exception handler). |
| `error` | An explicit error or failure path designed into the BPMN (for example, a BPMN error boundary event fires). |
| `boundary` | A test at the edge of a valid input range (for example, exactly the minimum or maximum allowed value). |
| `edge` | An unusual but technically valid scenario (for example, a 0-item list, a null optional field, a same-day start and due date). |

---

## Minimal example

```json
{
  "schema_version": "1.0",
  "app": {
    "name": "Standard Employee Requisition",
    "acronym": "SER",
    "snapshot": "SERV100",
    "process_model": "Standard Employee Requisition"
  },
  "generated_at": "2026-08-15T10:00:00Z",
  "test_cases": [
    {
      "id": "TC-001",
      "name": "Happy path — requisition approved",
      "type": "process",
      "path": "happy",
      "description": "A hiring manager submits a requisition that is approved by HR and Finance.",
      "preconditions": { "description": "No open requisitions for the same position.", "required_data": {} },
      "input": { "description": "Minimal valid requisition data", "data": { "position_title": "Software Engineer", "num_openings": 1 } },
      "steps": [
        {
          "step_number": 1,
          "task_name": "Submit Requisition",
          "description": "Hiring manager fills in the requisition form.",
          "expected_business_data": {},
          "output": { "position_title": "Software Engineer", "num_openings": 1, "budget_approved": true },
          "expected_next": { "task_or_gateway": "HR Review", "rationale": "Standard flow — budget approved, routed to HR." }
        },
        {
          "step_number": 2,
          "task_name": "HR Review",
          "description": "HR reviews and approves.",
          "expected_business_data": { "position_title": "Software Engineer" },
          "output": { "hr_approved": true },
          "expected_next": { "task_or_gateway": "[End Event]", "rationale": "HR approved — process completes." }
        }
      ],
      "expected_outcome": {
        "final_status": "Completed",
        "output_variables": { "hr_approved": true },
        "notes": "Process should reach the 'Approved' end event."
      },
      "coach_assertions": [],
      "tags": ["smoke"]
    }
  ]
}
```

---

## Human-readable output format (`<acronym>-test-suite.md`)

At the end of Phase A, produce this markdown file alongside the JSON. It supports human review, coverage sign-off, gap spotting, and sharing with stakeholders who do not open a JSON file.

### File structure

```markdown
# Test Suite — <App Name> (<ACRONYM>) · <Snapshot>
Generated: <ISO timestamp>   |   Process model: <process_model>

## Summary

| ID | Name | Type | Path |
|----|------|------|------|
| TC-001 | Happy path — new position approved | process | happy |
| TC-002 | GM rejects new position | process | alternative |
| ... | ... | ... | ... |

---

## TC-001 · Happy path — new position approved

**Type:** process  **Path:** happy

**Description:** One-sentence description of what this test validates.

**Preconditions:** What must be true before the test runs.

**Start data:**
- `field`: value
- `field`: value

**Steps:**

1. **Submit position request**
   - Completes with: `positionType = New`, `department = Engineering`, `empNum = 1`
   - Expects next: GM approval required (positionType == 'New')

2. **Review new position request** *(GM lane)*
   - Completes with: `gmApproval = true`
   - Expects next: Find job candidates

**Expected outcome:**
- Final status: `Completed`
- Output variables: `gmApproval = true`, `status = Approved`

---

## TC-002 · GM rejects new position
...
```

### Rules for the markdown file

- Use one `##` section per test case, labeled `TC-NNN · <name>`.
- The summary table at the top lists every test case. A reviewer scans this table first.
- Steps show only what the reader needs to understand the flow: task name, lane if relevant, key output values, and the expected next step. Do not dump the full JSON output block.
- Coach test cases (`type: coach`) replace the Steps section with an Assertions section that lists each field and its assertion type in plain English.
- Keep the language plain. QA engineers and business analysts read this file, not just developers.

